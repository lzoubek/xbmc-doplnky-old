# -*- coding: UTF-8 -*-
#/*
# *      Copyright (C) 2013 Libor Zoubek
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */
import re,urllib,urllib2,cookielib,random,util,sys,os,traceback
from provider import ContentProvider

import scrapper

class CSFDContentProvider(ContentProvider):

    def __init__(self,username=None,password=None,filter=None):
        ContentProvider.__init__(self,'csfd.cz','http://csfd.cz/',username,password,filter)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookielib.LWPCookieJar()))
        urllib2.install_opener(opener)

    def movie_item(self,url='',title=''):
        return self.dir_item(type='movie',url=url,title=title)

    def capabilities(self):
        return ['search','resolve','cagegories']

    def search(self,keyword):
        url = self._url('hledat/complete-films/?q='+urllib.quote(keyword))
        page = util.request(url)

        result = []
        data = util.substr(page,'<div id=\"search-films','<div class=\"footer')
        for m in re.finditer('<h3 class=\"subject\"[^<]+<a href=\"(?P<url>[^\"]+)[^>]+>(?P<name>[^<]+).+?<p>(?P<info>[^<]+)',data,re.DOTALL|re.IGNORECASE):
            item = self.movie_item(url='#get-m#'+m.group('url'))
            item['title'] = '%s (%s)' % (m.group('name'),m.group('info'))
            result.append(item)

        for m in re.finditer('<li(?P<item>.+?)</li>',util.substr(data,'<ul class=\"films others','</div'),re.DOTALL|re.IGNORECASE):
            base = re.search('<a href=\"(?P<url>[^\"]+)[^>]+>(?P<name>[^<]+)',m.group('item'))
            if base:
                name = base.group('name')
                for n in re.finditer('<span[^>]*>(?P<data>[^<]+)',m.group('item')):
                    name = '%s %s' % (name,n.group('data'))
                result.append(self.movie_item(url='#get-m#'+base.group('url'),title=name))
        return result

    def categories(self):
        result = []
        #result.append(self.dir_item(title='Oblíbené',url='#fav#'))
        #result.append(self.dir_item(title='Žebříčky',url='#top#'))
        #result.append(self.dir_item(title='Kino',url='#kino#'))
        #result.append(self.dir_item(title='Blue-ray',url='#blueray#'))
        #result.append(self.dir_item(title='Levná DVD',url='#dvd#'))
        #result.append(self.dir_item(title='Tvůrci',url='#artists#'))
        #result.append(self.dir_item(title='Chci vidět',url='#chcividet#'))
        return result

    def list(self,url):
        if url.find('#get-m#') == 0:
            return self.list_movie(url[7:])
        result = []
        return result

    def list_movie(self,url):
        result = []
        rel_url = url
        url = self._url(url)
        info = scrapper.get_info(url)
        xbmc_info = scrapper.xbmc_info(info)
        print info
        page = util.request(url.rstrip('/')+'/videa',headers={'Referer':self._url('')})
        data = page
        #xbmcutil.add_dir(__language__(30007),params,info['img'],infoLabels=xbmc_info,menuItems={__language__(30007):'Action(info)'})

        #add_addon_search(30006,'plugin.video.online-files',info,'search')
        def_trailer = None
        for m in re.finditer('<li id=\"(?P<id>video\-[^\"]+)(?P<body>.+?)</li>',data,re.DOTALL|re.IGNORECASE):
            id = m.group('id')
            body = m.group('body')
            item = self.video_item()
            item['url'] = '#video#%s#%s' % (rel_url,id)
            item['title'] = re.search('class=\"description\">([^<]+)',body).group(1)
            result.append(item)
        return result

    def resolve(self,item,captcha_cb=None,wait_cb=None):
        return None
