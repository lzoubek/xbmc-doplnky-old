# -*- coding: UTF-8 -*-
#/*
# *      Copyright (C) 2011 Libor Zoubek
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */

import xbmc,xbmcplugin,re,sys,traceback
import util
import xbmcutil
import unicodedata

def get_info(url):
	cached = None
	if cached:
		return cached
	else:
		info = _empty_info()

		try:
			page = util.request(url,headers={'Referer':BASE_URL,'User-Agent':util.UA})
		except:
			util.error('Unable to read page '+url)
			traceback.print_exc()
			info['url'] = url
			return info
		info['title'] = _get_title(page)
		info['search-title'] = _search_title(page)
		info['url'] = url
		info['trailers_url'] = url.rstrip('/')+'/videa/'
		info['cast'] = _cast(page)
		info['genre'] = _genre(page)
		info['img'] = _get_img(page)
		info['plot'] = _plot(page)
		country,info['year'] = _origin(page)
		info['percent'],info['rating'] = _rating(page)
		info['director'] = _director(page)
		info['votes'] = _votes(page)
		_validate(info)
		return info

def xbmc_info(info):
	ret  = {}
	ret['Plot'] = info['plot']
	ret['Plotoutline'] = info['plot'][:100]+'...'
	ret['Year'] = info['year']
	ret['Genre'] = info['genre']
	ret['Rating'] = info['rating']
	ret['Director'] = info['director']
	ret['Votes'] = info['votes']
	ret['Cast'] = info['cast']
	ret['Trailer'] = info['trailer']
	ret['Title'] = info['title']
	return ret

def _validate(info):
	dummy = _empty_info()
	for key in info.keys():
		if not type(info[key]) == type(dummy[key]):
			util.info('key '+key+' is type of '+str(type(info[key]))+' does not match required type '+str(type(dummy[key])))
			info[key] = dummy[key]
	for key in dummy.keys():
		if not key in info:
			info[key] = dummy[key]
